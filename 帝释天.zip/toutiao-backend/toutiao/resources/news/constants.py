# 文章详情相关文章推荐数量
RECOMMENDED_SIMILAR_ARTICLE_MAX = 10

# 设置下限的目地是保证置顶的评论在一页内请求完成
# 评论分页默认每页数量 下限
DEFAULT_COMMENT_PER_PAGE_MIN = 10

# 评论分页默认每页数量 上限
DEFAULT_COMMENT_PER_PAGE_MAX = 50

# 文章分页默认每页数量 下限
DEFAULT_ARTICLE_PER_PAGE_MIN = 10

# 文章分页默认每页数量 上限
DEFAULT_ARTICLE_PER_PAGE_MAX = 50
