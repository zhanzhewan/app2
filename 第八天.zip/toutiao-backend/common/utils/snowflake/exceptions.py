class InvalidSystemClock(Exception):
    """
    时钟回拨异常
    """
    pass
