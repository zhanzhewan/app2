# Token 机制



1. Token 有效期为2小时，每2小时刷新一次

2. 提供refresh_token，refresh_token 有效期14天

3. 凭借refresh_token 获取新token


